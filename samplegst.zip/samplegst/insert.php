<?php
include "dbconn.php";

if(isset($_POST['add']))
{
    $parnum = $_POST['parnum'];
    $qty = $_POST['qty'];
    $amnt = $_POST['amnt'];
    $gst = $_POST['gst'];
    $desc = $_POST['desc'];

    
    $insert = mysqli_query($db,"INSERT INTO `includegst`(`parnum`, `qty`, `amnt`, `gst`, `desc`) 
    VALUES('$parnum', '$qty', '$amnt', '$gst', '$desc')");
    
   if($insert)
    {
        echo " Submitted";
        echo header("location: index.php");
     }
    else
    {
        echo "please enter required fields";
    }
}
?>
   