<?php 
include "dbconn.php";
include "insert.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Include GST</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js" type="text/javascript"></script>
</head>
<body>
    <div class="container" style="margin-bottom: 70px;">
        <h1>Calculation of Include GST</h1>
        <form action="insert.php" method="post">
        <tabel>
            <tr>
             <td><input type="text" name="parnum" id="partnumber" placeholder="enter part number" required></td>
             <td><input type="text" name="qty" id="quantity" placeholder="enter  quantity" required></td>
             <td><input type="text" name="amnt" onchange="calculateAmount(this.value)" id="amount" placeholder="enter  amount" required></td>
             <td><input type="text" name="gst" id="gst" placeholder="gst" required></td>
             <td><input type="textarea" name="desc" id="desc" placeholder="enter description" required></td>
             <button class="btn" name="add">Add</button>
            </tr>
        </tabel>
    </form>
    
    </div>
    <table border="2" style="margin-left: 500px;">
        <tr>
            <th>PartNumber</th>
            <th>quantity</th>
            <th>Amount</th>
            <th>GST</th>
            <th>Description</th>
</tr>

<?php
error_reporting(0);
$query = "select * from includegst";
$data = mysqli_query($db,$query);
$total = mysqli_num_rows($data);

echo $result['parnum']." ".$result['qty']." ".$result['amnt']." ".$result['gst']." " .$result['desc'];
//echo "$total";

if($total!=0)
{
    
    while(($result = mysqli_fetch_assoc($data)))
    {
        echo "
        <tr>
        <td>".$result['parnum']."</td>
        <td>".$result['qty']."</td>
        <td>".$result['amnt']."</td>
        <td>".$result['gst']."</td>
        <td>".$result['desc']."</td> ";

    }
    
}
else{
    echo "table has no records";
}


?>
</table>
</body>




</html>
<script>
function calculateAmount(val)
{ 
	var price = val * 1;
	/*display the result*/
	var tot_price=Math.round(price * 100/118);
	var divobj = document.getElementById('gst');
	divobj.value = tot_price;
}
</script>
