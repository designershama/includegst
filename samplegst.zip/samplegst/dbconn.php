<?php

$db = mysqli_connect("localhost", "root", "", "test1");

if(!$db)
{
    die("connection failed:" . mysqli_connect_error());
}

?>